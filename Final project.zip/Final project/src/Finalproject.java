
import java.sql.DriverManager;
import javax.swing.JOptionPane;
import java.sql.*;
import javax.swing.table.DefaultTableModel;

public class Finalproject extends javax.swing.JFrame {

    
    public Finalproject() {
        initComponents();
       
    }
String gen;

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        group1 = new javax.swing.ButtonGroup();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        rbmale = new javax.swing.JRadioButton();
        rbfemale = new javax.swing.JRadioButton();
        btnsearch = new javax.swing.JButton();
        btnsave = new javax.swing.JButton();
        btndel = new javax.swing.JButton();
        btnclr = new javax.swing.JButton();
        btnup = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tab = new javax.swing.JTable();
        txtename = new javax.swing.JTextField();
        txteno = new javax.swing.JTextField();
        txtadd = new javax.swing.JTextField();
        btnexit1 = new javax.swing.JButton();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Calibri", 0, 16)); // NOI18N
        jLabel1.setText("Employee No:");

        jLabel2.setFont(new java.awt.Font("Calibri", 1, 22)); // NOI18N
        jLabel2.setText("Employee Registration");

        jLabel3.setFont(new java.awt.Font("Calibri", 0, 16)); // NOI18N
        jLabel3.setText("Address:");

        jLabel4.setFont(new java.awt.Font("Calibri", 0, 16)); // NOI18N
        jLabel4.setText("Employee Name:");

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 102, 102), 3, true), "Gender", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Arial Black", 0, 16), new java.awt.Color(0, 0, 153))); // NOI18N

        rbmale.setBackground(new java.awt.Color(204, 204, 255));
        group1.add(rbmale);
        rbmale.setFont(new java.awt.Font("Calibri", 0, 16)); // NOI18N
        rbmale.setForeground(new java.awt.Color(51, 51, 51));
        rbmale.setText("Male");

        rbfemale.setBackground(new java.awt.Color(204, 204, 255));
        group1.add(rbfemale);
        rbfemale.setFont(new java.awt.Font("Calibri", 0, 16)); // NOI18N
        rbfemale.setForeground(new java.awt.Color(51, 51, 51));
        rbfemale.setText("Female");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(72, 72, 72)
                .addComponent(rbmale)
                .addGap(147, 147, 147)
                .addComponent(rbfemale)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(rbmale)
                    .addComponent(rbfemale))
                .addContainerGap(16, Short.MAX_VALUE))
        );

        btnsearch.setBackground(new java.awt.Color(153, 255, 153));
        btnsearch.setFont(new java.awt.Font("Calibri", 1, 16)); // NOI18N
        btnsearch.setForeground(new java.awt.Color(51, 51, 51));
        btnsearch.setText("Search");
        btnsearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsearchActionPerformed(evt);
            }
        });

        btnsave.setBackground(new java.awt.Color(102, 102, 255));
        btnsave.setFont(new java.awt.Font("Calibri", 1, 16)); // NOI18N
        btnsave.setForeground(new java.awt.Color(51, 51, 51));
        btnsave.setText("Save");
        btnsave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsaveActionPerformed(evt);
            }
        });

        btndel.setBackground(new java.awt.Color(102, 102, 255));
        btndel.setFont(new java.awt.Font("Calibri", 1, 16)); // NOI18N
        btndel.setForeground(new java.awt.Color(51, 51, 51));
        btndel.setText("Delete");
        btndel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btndelActionPerformed(evt);
            }
        });

        btnclr.setBackground(new java.awt.Color(102, 102, 255));
        btnclr.setFont(new java.awt.Font("Calibri", 1, 16)); // NOI18N
        btnclr.setForeground(new java.awt.Color(51, 51, 51));
        btnclr.setText("Clear");
        btnclr.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnclrActionPerformed(evt);
            }
        });

        btnup.setBackground(new java.awt.Color(102, 102, 255));
        btnup.setFont(new java.awt.Font("Calibri", 1, 16)); // NOI18N
        btnup.setForeground(new java.awt.Color(51, 51, 51));
        btnup.setText("Update");
        btnup.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnupActionPerformed(evt);
            }
        });

        tab.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        tab.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Employee No", "Employee Name", "Address", "Gender"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tab.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tab);

        txtename.setFont(new java.awt.Font("Calibri", 0, 16)); // NOI18N

        txteno.setFont(new java.awt.Font("Calibri", 0, 16)); // NOI18N

        txtadd.setFont(new java.awt.Font("Calibri", 0, 16)); // NOI18N

        btnexit1.setBackground(new java.awt.Color(255, 153, 153));
        btnexit1.setFont(new java.awt.Font("Calibri", 1, 16)); // NOI18N
        btnexit1.setForeground(new java.awt.Color(51, 51, 51));
        btnexit1.setText("Exit");
        btnexit1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnexit1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 284, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 414, Short.MAX_VALUE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(txteno))
                            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(4, 4, 4)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtadd)
                                    .addComponent(txtename))))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(131, 131, 131)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btnsave, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btndel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnclr, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnup, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btnsearch, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnexit1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)))))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txteno, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnsearch, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtename, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnsave, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(23, 23, 23)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtadd, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btndel, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(btnclr, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(29, 29, 29)
                        .addComponent(btnup, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 7, Short.MAX_VALUE)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 208, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())
                    .addGroup(layout.createSequentialGroup()
                        .addGap(31, 31, 31)
                        .addComponent(btnexit1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnsearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsearchActionPerformed
        ref();
    }//GEN-LAST:event_btnsearchActionPerformed

    private void btnclrActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnclrActionPerformed
        clear();
    }//GEN-LAST:event_btnclrActionPerformed

    private void btnsaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsaveActionPerformed
     if(txteno.getText().equals("")){btnsave.setEnabled(false);}
     else if (txtename.getText().equals("")){btnsave.setEnabled(false);}
     else if (txtadd.getText().equals("")){btnsave.setEnabled(false);}
     else{btnsave.setEnabled(true);}
        try{
           Class.forName("java.sql.Driver");
           Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/employeedetails", "root","");
           
           if(rbfemale.isSelected()==true){gen ="Female";}
           else if(rbmale.isSelected()==true){gen ="male";}
      String saveque="INSERT INTO empdetails VALUES(?,?,?,?);";
      
    PreparedStatement cmd=con.prepareStatement(saveque);
    cmd.setString(1, txteno.getText());
    cmd.setString(2, txtename.getText());
    cmd.setString(3, txtadd.getText());
    cmd.setString(4, gen);
    cmd.execute();
    
    JOptionPane.showMessageDialog(this, "Record of"+txteno.getText()+"("+txtename.getText()+") successfully save to database","saved!",JOptionPane.INFORMATION_MESSAGE);
    
    clear();
    ref();
              }
       catch(Exception ex){ 
           JOptionPane.showMessageDialog(this, "Error while recording"+"\n"+ex);
       }
    }//GEN-LAST:event_btnsaveActionPerformed

    private void tabMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabMouseClicked
try{
            Class.forName("java.sql.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/employeedetails","root","");
            
        btnsave.setEnabled(false);
        btnup.setEnabled(true);
        btndel.setEnabled(true);
        txteno.setEditable(false);
    int row=tab.getSelectedRow();
    
    String sr=(tab.getModel().getValueAt(row, 0).toString());
    String selque="SELECT*FROM empdetails WHERE ENo="+sr+";";
    Statement st=con.createStatement();
    ResultSet rs=st.executeQuery(selque);
    
    if(rs.next()){
                txteno.setText(rs.getString("ENo"));
                txtename.setText(rs.getString("EName"));
                txtadd.setText(rs.getString("Addrs"));
                gen=(rs.getString("Gen"));
    if("male".equals(gen)){rbmale.setSelected(true);}          
    else if("female".equals(gen)){rbfemale.setSelected(true);}
    
    }
        
        }
catch(Exception ex)   
{
JOptionPane.showMessageDialog(this, "Error while loading..."+"/n"+ex);
}
    }//GEN-LAST:event_tabMouseClicked

    private void btnupActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnupActionPerformed
       try {
             Class.forName("java.sql.Driver");
             Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/employeedetails","root","");
              int res=JOptionPane.showConfirmDialog(null,"Are you sure want to update?"+txtename.getText(),"Update?",JOptionPane.QUESTION_MESSAGE);
              if (res==0){
                          if(rbmale.isSelected()==true){gen="male";}
                          else if(rbfemale.isSelected()==true){gen="female";}
              String updateque="UPDATE empdetails SET EName=?,Addrs=?,Gen=?"+"WHERE ENo=?;";            
              PreparedStatement cmd=con.prepareStatement(updateque);
              
              cmd.setString(1, txtename.getText());
              cmd.setString(2, txtadd.getText());
              cmd.setString(3, gen);
              cmd.setString(4, txteno.getText());
 
              cmd.executeUpdate();
             
    JOptionPane.showMessageDialog(this, "Successfully Saved!","Saved!",JOptionPane.INFORMATION_MESSAGE);
    clear();
    ref();
              }
          
       }
       catch(Exception ex)
            {
                JOptionPane.showMessageDialog(this, "Error while updating...\n "+"\n"+ex);
            }    
    }//GEN-LAST:event_btnupActionPerformed

    private void btndelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btndelActionPerformed
        try{
            Class.forName("java.sql.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/employeedetails","root","");
            String eid=txteno.getText();
            int res=JOptionPane.showConfirmDialog(null, "Are you sure want to delete"+eid+"from database?","confirm..",JOptionPane.QUESTION_MESSAGE);
            if(res==0){String delque="DELETE*FROM empdetails WHERE ENo="+eid+"; ";
            PreparedStatement cmd=con.prepareStatement(delque);
                              cmd.executeQuery();
            }
            JOptionPane.showMessageDialog(this, "successfully deleted."+eid+"from database","Deleted!",JOptionPane.INFORMATION_MESSAGE);
            clear();
            ref();
            }
    
        catch(Exception ex){JOptionPane.showMessageDialog(this, "Error while deleting"+"\n"+ex);}
    }//GEN-LAST:event_btndelActionPerformed

    private void btnexit1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnexit1ActionPerformed
       int y=JOptionPane.showConfirmDialog(null, "Are You Sure Want to Exit?","EXIT",JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE);
        if(y==0){this.dispose();};
    }//GEN-LAST:event_btnexit1ActionPerformed
    
private void clear(){
txteno.setText("");
txtename.setText("");
txtadd.setText("");
rbmale.setSelected(false);
rbfemale.setSelected(false);
txteno.setEditable(true);
btnsave.setEnabled(true);
btnup.setEnabled(true);
btndel.setEnabled(true);
txteno.requestFocus();

}
public void ref(){DefaultTableModel mod=(DefaultTableModel)tab.getModel();
                  mod.setRowCount(0);


try{
     Class.forName("java.sql.Driver");
     Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/employeedetails", "root","");
     
     Statement st=con.createStatement();
     String selque="SELECT*FROM empdetails;";
     ResultSet rs=st.executeQuery(selque); 
     
     while(rs.next()){
     String ap1=rs.getString("ENo");
     String ap2=rs.getString("EName");
     String ap3=rs.getString("Addrs");
     String ap4=rs.getString("Gen");
     
     mod.addRow(new Object[]{ap1,ap2,ap3,ap4});
     rs.close();
     st.close();
     con.close();
     }  
         }
catch(Exception ex){
    JOptionPane.showMessageDialog(this, "Error while refreshing..."+"/n"+ex);
}
}
public static void main(String args[]) {
       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Finalproject().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnclr;
    private javax.swing.JButton btndel;
    private javax.swing.JButton btnexit1;
    private javax.swing.JButton btnsave;
    private javax.swing.JButton btnsearch;
    private javax.swing.JButton btnup;
    private javax.swing.ButtonGroup group1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JRadioButton rbfemale;
    private javax.swing.JRadioButton rbmale;
    private javax.swing.JTable tab;
    private javax.swing.JTextField txtadd;
    private javax.swing.JTextField txtename;
    private javax.swing.JTextField txteno;
    // End of variables declaration//GEN-END:variables
}
